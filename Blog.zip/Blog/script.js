function Dogs() {
    var heading = document.getElementById("Cats");
    heading.innerHTML = "I love dogs.";
}

function Cats() {
    var heading = document.getElementById("Cats");
    heading.innerHTML = "I love cats.";
}